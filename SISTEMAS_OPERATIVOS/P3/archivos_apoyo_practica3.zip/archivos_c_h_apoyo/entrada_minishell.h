#ifndef ENTRADA_MINISHELL_H
#define ENTRADA_MINISHELL_H

void leer_linea_ordenes(char *cad);
void imprimir_prompt();

#endif
