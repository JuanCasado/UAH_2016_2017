#ifndef SIMULA_CAR_H
#define SIMULA_CAR_H

void *funcion_coche(coche_t *);

#endif
